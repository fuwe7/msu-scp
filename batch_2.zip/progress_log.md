# Журнал прогресса

Батч 0 — reference.md — round_counter: 2 — known limitations: нет — статус: одобрено

Батч 1:
Engine: header.html — round_counter: 1 — known limitations: нет — статус: одобрено
Engine: footer.html — round_counter: 1 — known limitations: нет — статус: одобрено
Engine: article-template.html — round_counter: 1 — known limitations: нет — статус: одобрено
Engine: dossier-location-template.html — round_counter: 1 — known limitations: нет — статус: одобрено
Engine: theory-doc-template.html — round_counter: 1 — known limitations: нет — статус: одобрено
Engine: incident-report-template.html — round_counter: 1 — known limitations: нет — статус: одобрено
Engine: tale-template.html — round_counter: 1 — known limitations: нет — статус: одобрено
Engine: dossier-personnel-template.html — round_counter: 1 — known limitations: нет — статус: одобрено
Engine: hub-template.html — round_counter: 1 — known limitations: нет — статус: одобрено
Engine: tales-hub.html — round_counter: 1 — known limitations: нет — статус: одобрено
Engine: index.html — round_counter: 1 — known limitations: нет — статус: одобрено
Engine: about-template.html — round_counter: 1 — known limitations: нет — статус: одобрено

Батч 2:
ОСТАНОВЛЕНО НА ОШИБКЕ — Страница: pages/tale-intro.md — Роль: immersion_checker — Этап: проверка черновика (round 1) — Ошибка: HTTP 429 Resource Exhausted (API call failed after 3 retries)